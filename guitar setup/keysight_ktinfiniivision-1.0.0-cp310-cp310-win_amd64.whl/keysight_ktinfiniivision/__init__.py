
# BEGIN ROOFTOP-GENERATED CODE --- Do not edit or insert code in this region ---
import pathlib, os, sys


def add_library_path_win(dll_paths):
    for p in dll_paths:
        os.environ['PATH'] = p + os.pathsep + os.environ['PATH']
        if (sys.version_info.major == 3 and sys.version_info.minor >= 8) or sys.version_info.major >3:
            os.add_dll_directory(p)


def add_library_path_linux(dll_paths):
    for p in dll_paths:
        if 'LD_LIBRARY_PATH' not in os.environ:
            os.environ['LD_LIBRARY_PATH'] = p          
        else:
            os.environ['LD_LIBRARY_PATH'] = p + os.pathsep + os.environ['LD_LIBRARY_PATH']


# - Set DLL load path, it is different in Windows and Linux 
dll_paths = []
dll_paths.append(str(pathlib.Path(__file__).parents[1]))

if sys.platform == 'win32':
    add_library_path_win(dll_paths) 
else:
    # - We want to set LD_LIBRARY_PATH before importing but it doesn't work, so we use a workaround to re-excute the script to make the path work 
    # - See discussion in https://stackoverflow.com/questions/23244418/set-ld-library-path-before-importing-in-python
    if 'KtInfiniiVision_LD_PATH_ADDED' not in os.environ:
        os.environ['KtInfiniiVision_LD_PATH_ADDED'] = 'True'
        add_library_path_linux(dll_paths) 
        os.execv(sys.executable, [sys.executable] + sys.argv)

# Set environment variable for enabled apis
os.environ["KtInfiniiVision_enabledapis"] = "KtInfiniiVision"

# Expose all the capabilities keysight_ktinfiniivision.pyd
from .keysight_ktinfiniivision import *
# END ROOFTOP-GENERATED CODE --- Do not edit or insert code in this region ---

__version__ = keysight_ktinfiniivision.__version__
__author__ = keysight_ktinfiniivision.__author__
__license__ = keysight_ktinfiniivision.__license__
__copyright__ = keysight_ktinfiniivision.__copyright__
__doc__ = keysight_ktinfiniivision.__doc__
